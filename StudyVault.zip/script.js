const search=document.getElementById('search');
search.addEventListener('keyup',()=>{
const value=search.value.toLowerCase();
document.querySelectorAll('.card').forEach(card=>{
const title=card.querySelector('h2').innerText.toLowerCase();
card.style.display=title.includes(value)?'block':'none';
});
});